# Deployment checklist

- [ ] Confirm local `npm install` and `npm run build` succeed.
- [ ] Configure `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in deployment environment variables.
- [ ] Apply `supabase/admin_backend_migration.sql` in Supabase SQL Editor.
- [ ] Create admin Auth user and add UUID to `public.admin_users`.
- [ ] Configure Cloudflare's current Next.js deployment adapter and verify routes/API behavior.
- [ ] Confirm RLS policies, auth redirect behavior, and product click endpoint in production.
- [ ] Keep all 250 products in draft until listing and affiliate QA is complete.
