# GiftScout

GiftScout is a gift-discovery platform with personalized product recommendations, a 250-product draft catalog in Supabase, and an admin workspace.

## Stack
- Next.js 15 App Router / React 19 / TypeScript
- Supabase Auth, Postgres, and Row Level Security
- Tailwind-free custom CSS

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and fill in the Supabase project URL and anon/publishable key.
4. Run `npm run dev` and open http://localhost:3000.

## Environment variables
`NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` are public browser credentials protected by Supabase RLS. Never add a service-role key to this project or commit `.env.local`.

## Supabase setup
- The initial schema is in `supabase/schema.sql`.
- The admin additions are in `supabase/admin_backend_migration.sql`.
- Create an administrator using Supabase Authentication, then add that user's UUID to `public.admin_users` using the SQL instructions in the migration file.
- The admin page checks membership using the database function `is_giftscout_admin()`.

## Catalog status
The 250 catalog records are intentionally drafts. Do not activate products until product URLs, prices, availability, image rights, and affiliate tracking links have been verified. The current catalog import has no affiliate URLs or product image URLs yet.

## Current limitations
- Affiliate network approval and conversion reporting are not configured.
- Product image upload is not implemented; the admin form supports image URLs.
- Paid sponsor billing and checkout are not implemented.
- Review privacy policy, terms, affiliate disclosures, and retailer program requirements before public launch.

## Deployment
This repository is prepared for GitHub. Deployment target is Cloudflare Pages/Workers using the current supported Next.js adapter; test the production build and adapter compatibility before connecting a public domain. A free `*.pages.dev` address can be used initially.
