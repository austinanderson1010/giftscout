-- GiftScout admin access + catalog management migration
-- Run AFTER creating the admin's Supabase Auth user.
-- Replace the UUID in the final INSERT with that user's Auth UID.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

-- Admins can verify their own membership. No client-side role assignment is allowed.
drop policy if exists "Admins can read own admin membership" on public.admin_users;
create policy "Admins can read own admin membership"
on public.admin_users for select
to authenticated
using (user_id = (select auth.uid()));

-- SECURITY DEFINER helper avoids recursive RLS policy evaluation.
create or replace function public.is_giftscout_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.admin_users au
    where au.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_giftscout_admin() from public;
grant execute on function public.is_giftscout_admin() to authenticated;

-- Product policies: public can still read active products; only admins can read all
-- products and insert/update/archive them.
drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products"
on public.products for select
to anon, authenticated
using (status = 'active');

drop policy if exists "Admins can read all products" on public.products;
create policy "Admins can read all products"
on public.products for select
to authenticated
using ((select public.is_giftscout_admin()));

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
on public.products for insert
to authenticated
with check ((select public.is_giftscout_admin()));

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
on public.products for update
to authenticated
using ((select public.is_giftscout_admin()))
with check ((select public.is_giftscout_admin()));

-- Admin-only access to click data, brands and sponsorship campaigns.
drop policy if exists "Admins can read product clicks" on public.product_clicks;
create policy "Admins can read product clicks"
on public.product_clicks for select
to authenticated
using ((select public.is_giftscout_admin()));

drop policy if exists "Admins can manage brands" on public.brands;
create policy "Admins can manage brands"
on public.brands for all
to authenticated
using ((select public.is_giftscout_admin()))
with check ((select public.is_giftscout_admin()));

drop policy if exists "Admins can manage sponsor campaigns" on public.sponsor_campaigns;
create policy "Admins can manage sponsor campaigns"
on public.sponsor_campaigns for all
to authenticated
using ((select public.is_giftscout_admin()))
with check ((select public.is_giftscout_admin()));

-- Keep product updated_at current on edits.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at
before update on public.products
for each row execute function public.set_updated_at();

-- IMPORTANT: Add the administrator only after creating the user in
-- Supabase Dashboard > Authentication > Users.
-- Then run a separate statement using that user's actual UUID:
-- insert into public.admin_users (user_id) values ('PASTE-AUTH-USER-UUID-HERE');
